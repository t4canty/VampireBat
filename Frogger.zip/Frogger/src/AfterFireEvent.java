
public class AfterFireEvent implements FireEventListener{

	@Override
	public boolean onFireEvent() {
		return false;
	}
	

}
