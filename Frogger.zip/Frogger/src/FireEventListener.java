
public interface FireEventListener {

	boolean onFireEvent();
}
